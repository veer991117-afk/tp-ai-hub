# TP-AI-HUB

A minimal runnable Android + Node.js starter project.

## Backend
```bash
cd backend
npm install
cp .env.example .env
npm start
```

The backend runs on port 3000.

## Android
Open the `android` folder in Android Studio, let Gradle sync, then run the app.

For an Android emulator the app uses `http://10.0.2.2:3000/`.
For a physical phone, change `API_BASE_URL` in `android/app/build.gradle` to your computer's LAN IP, for example `http://192.168.1.10:3000/`.

## API
- GET `/api/health`
- POST `/api/auth/signup`
- POST `/api/auth/login`
